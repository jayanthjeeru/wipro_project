package com.stackroute.ecommercev2.product.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.ecommercev2.product.service.ProductService;

@RestController
@RequestMapping("/ecommerce/product/api/v2")
public class DeleteProductController {
	private ProductService productService;
	
	public DeleteProductController(ProductService productService) {
		this.productService = productService;
	}
	
	@GetMapping("/deleteproductbyname")
	public String performOperation1(@RequestParam String productName) {
		return productService.removeProductByName(productName);
	}
	
	@GetMapping("/deleteproductbyid")
	public String performOperation2(@RequestParam int productId) {
		return productService.removeProductById(productId);
	}
}