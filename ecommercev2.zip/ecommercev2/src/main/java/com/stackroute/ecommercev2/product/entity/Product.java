package com.stackroute.ecommercev2.product.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_information")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "pro_id")
	private int id;
	@Column(name = "pro_name")
	private String name;
	@Column(name = "pro_company")
	private String company;
	@Column(name = "pro_price")
	private double price;
	@Column(name = "pro_description")
	private String description;
	@Column(name = "pro_category")
	private String category;
	@Column(name = "pro_sub_category")
	private String subCategory;
	
	public Product() {
	}
	
	public Product(int id, String name, String company, double price, String description, String category, String subCategory) {
		this.id = id;
		this.name = name;
		this.company = company;
		this.price = price;
		this.description = description;
		this.category = category;
		this.subCategory = subCategory;
	}
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getCompany() {
		return company;
	}
	
	public double getPrice() {
		return price;
	}
	
	public String getDescription() {
		return description;
	}
	
	public String getCategory() {
		return category;
	}
	
	public String getSubCategory() {
		return subCategory;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setCompany(String company) {
		this.company = company;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}	
}