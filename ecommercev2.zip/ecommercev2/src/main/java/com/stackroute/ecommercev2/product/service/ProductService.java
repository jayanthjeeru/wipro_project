package com.stackroute.ecommercev2.product.service;

import org.springframework.stereotype.Service;

import com.stackroute.ecommercev2.product.dao.ProductDao;
import com.stackroute.ecommercev2.product.entity.Product;

@Service
public class ProductService {
	private ProductDao productDao;
	
	public ProductService(ProductDao productDao) {
		this.productDao = productDao;
	}
	
	public String addProduct(Product product) {
		return productDao.insertProduct(product);
	}
	
	public String getProductById(int productId) {
		return productDao.selectProductById(productId);
	}
	
	public String getProductByName(String productName) {
		return productDao.selectProductByName(productName);
	}
	
	public String getProductsByCompany(String companyName) {
		return productDao.selectProductsByCompany(companyName);
	}
	
	public String getProductsByCategory(String categoryName) {
		return productDao.selectProductsByCategory(categoryName);
	}
	
	public String getProductsBySubCategory(String subCategoryName) {
		return productDao.selectProductsBySubCategory(subCategoryName);
	}
	
	public String getAllProducts() {
		return productDao.selectAllProducts();
	}
	
	public String removeProductByName(String productName) {
		return productDao.deleteProductByName(productName);
	}
	
	public String removeProductById(int productId) {
		return productDao.deleteProductById(productId);
	}
	
	public String modifyProduct(Product product) {
		return productDao.updateProduct(product);
	}
}