package com.stackroute.ecommercev2.product.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.ecommercev2.product.entity.Product;

@Repository
public class ProductDao {
	private SessionFactory sessionFactory;
	
	@Autowired
	public ProductDao(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}	
	
	public String insertProduct(Product product) {
		String status = "failure";
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(product);
		
		tx.commit();
		session.close();
		status = "success";
		
		return status;
	}
	
	public String selectProductById(int productId) {
		String jsonText = "failure";
		
		Session session = sessionFactory.openSession();
		
		Product product = session.get(Product.class, productId);
		if(product != null) {
			JSONObject jsonObject = new JSONObject(product);
			jsonText = jsonObject.toString();
		}
		
		session.close();
		
		return jsonText;
	}
	
	public String selectProductByName(String productName) {
		String jsonText = "failure";
		
		Session session = sessionFactory.openSession();
		
		String hql = "FROM Product p WHERE p.name=:productName";
		
		Query<Product> query = session.createQuery(hql);
		query.setParameter("productName", productName);
		
		List<Product> productsList = query.list();
		if(!(productsList.isEmpty())) {
			Product product = productsList.get(0);
			
			JSONObject jsonObject = new JSONObject(product);
			jsonText = jsonObject.toString();
		}
		
		session.close();
		
		return jsonText;
	}
	
	public String selectProductsByCompany(String companyName) {
		String jsonText = "failure";
		
		Session session = sessionFactory.openSession();
		
		String hql = "FROM Product p WHERE p.company=:companyName";
		
		Query<Product> query = session.createQuery(hql);
		query.setParameter("companyName", companyName);
		
		List<Product> productsList = query.list();
		if(!(productsList.isEmpty())) {
			JSONArray jsonArray = new JSONArray(productsList);
			
			jsonText = jsonArray.toString();
		}
		
		session.close();
		
		return jsonText;
	}
	
	public String selectProductsByCategory(String categoryName) {
		String jsonText = "failure";
		
		Session session = sessionFactory.openSession();
		
		String hql = "FROM Product p WHERE p.category=:categoryName";
		
		Query<Product> query = session.createQuery(hql);
		query.setParameter("categoryName", categoryName);
		
		List<Product> productsList = query.list();
		if(!(productsList.isEmpty())) {
			JSONArray jsonArray = new JSONArray(productsList);
			
			jsonText = jsonArray.toString();
		}
		
		session.close();
		
		return jsonText;
	}
	
	public String selectProductsBySubCategory(String subCategoryName) {
		String jsonText = "failure";
		
		Session session = sessionFactory.openSession();
		
		String hql = "FROM Product p WHERE p.subCategory=:subCategoryName";
		
		Query<Product> query = session.createQuery(hql);
		query.setParameter("subCategoryName", subCategoryName);
		
		List<Product> productsList = query.list();
		if(!(productsList.isEmpty())) {
			JSONArray jsonArray = new JSONArray(productsList);
			
			jsonText = jsonArray.toString();
		}
		
		session.close();
		
		return jsonText;
	}
	
	public String selectAllProducts() {
		String jsonText = "failure";
		
		Session session = sessionFactory.openSession();
		
		String hql = "FROM Product";
		
		Query<Product> query = session.createQuery(hql);
		
		List<Product> productsList = query.list();
		if(!(productsList.isEmpty())) {
			JSONArray jsonArray = new JSONArray(productsList);
			
			jsonText = jsonArray.toString();
		}
		
		session.close();
		
		return jsonText;
	}
	
	public String deleteProductByName(String productName) {
		String status = "failure";
		
		Session session = sessionFactory.openSession();
		
		String hql = "FROM Product p WHERE p.name=:name";
		
		Query<Product> query = session.createQuery(hql);
		query.setString("name", productName);
		
		List<Product> productsList = query.list();
		if(!(productsList.isEmpty())) {
			Product product = productsList.get(0);
			
			Transaction tx = session.beginTransaction(); 
			session.delete(product);
			tx.commit();
			status = "success";
		}
		
		session.close();
		
		return status;
	}
	
	public String deleteProductById(int productId) {
		String status = "failure";
		
		Session session = sessionFactory.openSession();
		
		Product product = session.get(Product.class, productId);
		if(product != null) {
			Transaction tx = session.beginTransaction();
			
			session.delete(product);
			
			tx.commit();
			status = "success";
		}
		
		session.close();
		
		return status;
	}
	
	public String updateProduct(Product product) {
		String status = "failure";
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		session.update(product);
		
		tx.commit();
		session.close();
		status = "success";
		
		return status;
	}
}