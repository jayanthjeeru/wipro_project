package com.stackroute.ecommercev2.product.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.ecommercev2.product.entity.Product;
import com.stackroute.ecommercev2.product.service.ProductService;

@RestController
@RequestMapping("/ecommerce/product/api/v2")
public class AddProductController {
	private ProductService productService;
	
	public AddProductController(ProductService productService) {
		this.productService = productService;
	}
	
	@GetMapping("/addproduct")
	public String performOperation(@RequestParam String name, @RequestParam String company, @RequestParam double price, @RequestParam String description, @RequestParam String category, @RequestParam String subCategory) {
		Product product = new Product();
		product.setName(name);
		product.setCompany(company);
		product.setPrice(price);
		product.setDescription(description);
		product.setCategory(category);
		product.setSubCategory(subCategory);
		
		return productService.addProduct(product);
	}
}