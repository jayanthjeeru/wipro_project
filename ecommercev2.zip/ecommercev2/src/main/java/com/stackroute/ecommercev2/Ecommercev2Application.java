package com.stackroute.ecommercev2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ecommercev2Application {
	public static void main(String[] args) {
		SpringApplication.run(Ecommercev2Application.class, args);
	}
}