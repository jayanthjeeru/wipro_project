package com.stackroute.ecommercev2.product.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.ecommercev2.product.service.ProductService;

@RestController
@CrossOrigin(origins = "http://127.0.0.1:5500")
@RequestMapping("/ecommerce/product/api/v2")
public class GetProductController {
	private ProductService productService;
	
	public GetProductController(ProductService productService) {
		this.productService = productService;
	}
	
	@GetMapping("/getproductbyid")
	public String performOperation1(@RequestParam int productId) {
		return productService.getProductById(productId);
	}
	
	@GetMapping("/getproductbyname")
	public String performOperation2(@RequestParam String productName) {
		return productService.getProductByName(productName);
	}
	
	@GetMapping("/getproductsbycompany")
	public String performOperation3(@RequestParam String companyName) {
		return productService.getProductsByCompany(companyName);
	}
	
	@GetMapping("/getproductsbycategory")
	public String performOperation4(@RequestParam String categoryName) {
		return productService.getProductsByCategory(categoryName);
	}
	
	@GetMapping("/getproductsbysubcategory")
	public String performOperation5(@RequestParam String subCategoryName) {
		return productService.getProductsBySubCategory(subCategoryName);
	}
	
	@GetMapping("/getallproducts")
	public String performOperation6() {
		return productService.getAllProducts();
	}
}